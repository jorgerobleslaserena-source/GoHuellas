import React from 'react';
import { Heart, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <Heart className="h-8 w-8 text-blue-400" />
              <div>
                <h3 className="text-xl font-bold">Conexión Pets Chile</h3>
                <p className="text-blue-400 text-sm">Cuidado integral para mascotas</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Plataforma especializada en el bienestar de mascotas y tutores, 
              ofreciendo servicios veterinarios y de acompañamiento de forma remota 
              en todo Chile.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                <Twitter className="h-6 w-6" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Servicios</h4>
            <ul className="space-y-3 text-gray-300">
              <li><a href="#" className="hover:text-white transition-colors duration-200">Consultas Veterinarias</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-200">Acompañamiento Psicológico</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-200">Terapias Complementarias</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-200">Consejería</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Información</h4>
            <ul className="space-y-3 text-gray-300">
              <li><a href="#" className="hover:text-white transition-colors duration-200">Sobre Nosotros</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-200">Términos y Condiciones</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-200">Política de Privacidad</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-200">Preguntas Frecuentes</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Conexión Pets Chile. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;