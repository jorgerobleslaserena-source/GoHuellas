import React from 'react';
import { Star } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'María González',
      pet: 'Luna (Gata)',
      rating: 5,
      text: 'El servicio de acompañamiento psicológico me ayudó mucho durante la enfermedad de Luna. Los profesionales son muy empáticos y comprensivos.'
    },
    {
      name: 'Carlos Mendoza',
      pet: 'Max (Perro)',
      rating: 5,
      text: 'La consulta veterinaria online fue increíble. Pudieron diagnosticar el problema de Max rápidamente y el tratamiento funcionó perfecto.'
    },
    {
      name: 'Ana Ruiz',
      pet: 'Mimi (Coneja)',
      rating: 5,
      text: 'Las terapias complementarias han mejorado muchísimo la calidad de vida de Mimi. El equipo es muy profesional y dedicado.'
    },
    {
      name: 'Pedro Silva',
      pet: 'Rocky (Perro)',
      rating: 5,
      text: 'Excelente servicio de consejería. Me ayudaron a entender mejor el comportamiento de Rocky y ahora nuestra relación es mucho mejor.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Lo que dicen nuestros clientes
          </h2>
          <p className="text-xl text-gray-600">
            La satisfacción de nuestros tutores y sus mascotas es nuestra prioridad
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300"
            >
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, starIndex) => (
                  <Star key={starIndex} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <p className="text-gray-600 mb-6 leading-relaxed italic">
                "{testimonial.text}"
              </p>
              
              <div className="border-t pt-4">
                <p className="font-semibold text-gray-900">{testimonial.name}</p>
                <p className="text-gray-600 text-sm">Tutor de {testimonial.pet}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;