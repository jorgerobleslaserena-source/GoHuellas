import React from 'react';
import { Shield, Users, Clock, Award } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Users, number: '500+', label: 'Mascotas Atendidas' },
    { icon: Clock, number: '24/7', label: 'Disponibilidad' },
    { icon: Shield, number: '100%', label: 'Profesionales Certificados' },
    { icon: Award, number: '5★', label: 'Calificación Promedio' }
  ];

  return (
    <section id="nosotros" className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Comprometidos con el bienestar de tu mascota
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              En Conexión Pets Chile entendemos que las mascotas son parte de la familia. 
              Por eso hemos desarrollado una plataforma integral que conecta a tutores 
              responsables con profesionales especializados en el cuidado animal.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Nuestro equipo multidisciplinario está compuesto por veterinarios, 
              psicólogos especializados en el vínculo humano-animal, y terapeutas 
              complementarios, todos comprometidos con brindar la mejor atención.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="bg-white p-4 rounded-2xl shadow-md mb-3 inline-block">
                    <stat.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.number}</p>
                  <p className="text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.pexels.com/photos/6235648/pexels-photo-6235648.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Equipo veterinario profesional"
              className="rounded-2xl shadow-2xl w-full"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
              <p className="text-sm text-gray-600 mb-1">Atención profesional</p>
              <p className="text-2xl font-bold text-blue-600">En todo Chile</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;