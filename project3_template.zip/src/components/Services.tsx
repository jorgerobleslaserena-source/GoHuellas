import React from 'react';
import { Stethoscope, Brain, Flower2, MessageCircle } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Stethoscope,
      title: 'Consultas Veterinarias',
      description: 'Diagnóstico y tratamiento profesional con veterinarios certificados. Atención inmediata para emergencias y consultas rutinarias.',
      features: ['Diagnóstico remoto', 'Prescripción médica', 'Seguimiento post-consulta', 'Emergencias 24/7']
    },
    {
      icon: Brain,
      title: 'Acompañamiento Psicológico',
      description: 'Soporte emocional especializado para tutores que enfrentan situaciones difíciles con sus mascotas.',
      features: ['Duelo por pérdida', 'Ansiedad del tutor', 'Adaptación a nuevas mascotas', 'Manejo del estrés']
    },
    {
      icon: Flower2,
      title: 'Terapias Complementarias',
      description: 'Tratamientos holísticos que complementan la medicina tradicional para el bienestar integral de tu mascota.',
      features: ['Aromaterapia', 'Flores de Bach', 'Reiki para mascotas', 'Medicina natural']
    },
    {
      icon: MessageCircle,
      title: 'Consejería Especializada',
      description: 'Orientación profesional para mejorar la relación entre tutores y mascotas, abordando problemas de comportamiento.',
      features: ['Problemas de conducta', 'Entrenamiento básico', 'Socialización', 'Comunicación animal']
    }
  ];

  return (
    <section id="servicios" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ofrecemos una gama completa de servicios especializados para el bienestar 
            de tu mascota y tu tranquilidad como tutor responsable.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-gray-50 rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:transform hover:-translate-y-2"
            >
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-4 rounded-full mr-4">
                  <service.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{service.title}</h3>
              </div>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              
              <ul className="space-y-3">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-700">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;