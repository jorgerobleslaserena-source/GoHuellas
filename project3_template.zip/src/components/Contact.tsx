import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const Contact = () => {
  const contactInfo = [
    {
      icon: Phone,
      title: 'Teléfono',
      info: '+56 2 2345 6789',
      description: 'Lunes a Domingo 8:00 - 22:00'
    },
    {
      icon: Mail,
      title: 'Email',
      info: 'contacto@conexionpets.cl',
      description: 'Respuesta en 24 horas'
    },
    {
      icon: MapPin,
      title: 'Cobertura',
      info: 'Todo Chile',
      description: 'Servicios remotos disponibles'
    },
    {
      icon: Clock,
      title: 'Emergencias',
      info: '24/7',
      description: 'Atención de urgencias'
    }
  ];

  return (
    <section id="contacto" className="py-20 bg-gradient-to-br from-blue-900 to-blue-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            Contáctanos
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Estamos aquí para ayudarte. Contáctanos por cualquier consulta o 
            para más información sobre nuestros servicios.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {contactInfo.map((item, index) => (
            <div 
              key={index}
              className="text-center bg-white bg-opacity-10 rounded-2xl p-6 hover:bg-opacity-20 transition-all duration-300"
            >
              <div className="bg-white bg-opacity-20 p-4 rounded-full inline-block mb-4">
                <item.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">{item.title}</h3>
              <p className="text-lg font-semibold text-blue-100 mb-1">{item.info}</p>
              <p className="text-blue-200 text-sm">{item.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-white bg-opacity-10 rounded-2xl p-8 inline-block">
            <h3 className="text-2xl font-bold mb-4">¿Necesitas ayuda inmediata?</h3>
            <p className="text-blue-100 mb-6">
              Para emergencias veterinarias, contáctanos directamente
            </p>
            <a 
              href="tel:+56223456789"
              className="bg-orange-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-orange-700 transition-colors duration-200 inline-block"
            >
              Llamar Ahora
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;